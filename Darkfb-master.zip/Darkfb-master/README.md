Just have fun 
